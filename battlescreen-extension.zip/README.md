battlescreen-extension
======================

My Battlefield 4 battlescreen chrome extension

This extension allows the customization of battlescreen
colors to any of the game default color-blind settings
or a custom setting of the users choice.

Select custom to unlock the color sliders and input boxes.
Create your colors by changing the sliders or entering
specific RGB values in the input boxes.
